(function () {
    'use strict';

    angular
        .module('app')
        .controller('loanFormController', loanFormController);

    loanFormController.$inject = ['UserService', '$location', '$rootScope', 'FlashService'];
    function loanFormController(UserService, $location, $rootScope, FlashService) {
        var vm = this;
        alert("for now we dont have any DB to save these values");

        vm.saveForm = saveForm;

        function saveForm() {
           
        }
    }

})();