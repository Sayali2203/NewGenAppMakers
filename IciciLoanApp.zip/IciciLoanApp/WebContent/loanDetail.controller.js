
app.controller('loanDetailController', function(UserService, $location, $rootScope, FlashService) {

    var vm = this;
    alert("no DB connected.. to save these values");
    vm.saveFormDetails = saveFormDetails;

    function saveFormDetails() {
    	FlashService.Success(' successful', true);
        $location.path('/loanDetails');
    }


}); 